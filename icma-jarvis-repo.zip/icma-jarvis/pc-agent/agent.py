"""
ICMA Jarvis PC agent (Windows-first).

Safety design:
- Claude never runs commands. It only picks ONE action name from ACTIONS.
- Every action is a fixed function in this file. There is no shell access.
- Remote commands from your phone arrive only through the relay with RELAY_TOKEN.

Environment variables:
  LLM_API_KEY         free Groq key (https://console.groq.com); not needed for Ollama
  LLM_BASE_URL        default Groq; use http://localhost:11434/v1 for Ollama
  LLM_MODEL           default llama-3.3-70b-versatile; Ollama example: llama3.2
  RELAY_URL           wss://your-relay-domain/agent   (optional, for phone control)
  RELAY_TOKEN         long random secret shared with the relay and phone
  STUDY_LANG          en-US (default) or ur-PK
"""
import asyncio
import json
import os
import subprocess
import threading
import urllib.parse
import webbrowser
from pathlib import Path

from openai import OpenAI
import pyttsx3
import speech_recognition as sr
import websockets
from dotenv import load_dotenv

load_dotenv(Path(__file__).with_name(".env"))

LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "https://api.groq.com/openai/v1")
LLM_API_KEY = os.environ.get("LLM_API_KEY", "ollama")   # any text works for local Ollama
MODEL = os.environ.get("LLM_MODEL", "llama-3.3-70b-versatile")
WAKE_WORD = "jarvis"
LANG = os.environ.get("STUDY_LANG", "en-US")
RELAY_URL = os.environ.get("RELAY_URL", "")
RELAY_TOKEN = os.environ.get("RELAY_TOKEN", "")
PROGRESS_FILE = Path(__file__).with_name("progress.json")

# ---- Allowlists (edit these to your own paths and apps) ----
ALLOWED_APPS = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "word": "winword.exe",
}
ALLOWED_FOLDERS = {
    "study": r"C:\Users\Saif\Documents\Study",
}


engine = pyttsx3.init()


def speak(text: str) -> None:
    print("JARVIS:", text)
    engine.say(text)
    engine.runAndWait()


# ---- Fixed actions. Claude can only ask for one of these by name. ----
def act_open_youtube(arg: str) -> str:
    webbrowser.open("https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(arg))
    return "YouTube khol raha hoon."


def act_open_app(arg: str) -> str:
    exe = ALLOWED_APPS.get(arg.lower())
    if not exe:
        return "Ye app allowed list mein nahi hai."
    subprocess.Popen(exe, shell=True)
    return f"{arg} khol diya."


def act_open_folder(arg: str) -> str:
    path = ALLOWED_FOLDERS.get(arg.lower())
    if not path:
        return "Ye folder allowed list mein nahi hai."
    os.startfile(path)  # Windows only
    return f"{arg} folder khol diya."


def act_set_timer(arg: str) -> str:
    try:
        minutes = float(arg)
    except ValueError:
        return "Kitne minute ka timer?"
    minutes = max(1, min(minutes, 180))
    threading.Timer(minutes * 60, lambda: speak("Saif, chalo. Study time.")).start()
    return f"{int(minutes)} minute ka timer laga diya."


def act_study_status(_: str) -> str:
    if not PROGRESS_FILE.exists():
        return "Progress file nahi mili. progress.json banayein."
    data = json.loads(PROGRESS_FILE.read_text(encoding="utf-8"))
    parts = [f"{s['code']} {s['pct']} percent" for s in data.get("subjects", [])]
    return "Aapki progress: " + ", ".join(parts) + "."


def act_say(arg: str) -> str:
    return arg


ACTIONS = {
    "open_youtube": act_open_youtube,
    "open_app": act_open_app,
    "open_folder": act_open_folder,
    "set_timer": act_set_timer,
    "study_status": act_study_status,
    "say": act_say,
}

PLANNER_PROMPT = f"""You route commands for a personal study and PC assistant.
Pick exactly ONE action and reply with JSON only, no other text:
{{"action": "<name>", "arg": "<string>"}}

Actions:
- open_youtube: arg = search words
- open_app: arg = one of {list(ALLOWED_APPS)}
- open_folder: arg = one of {list(ALLOWED_FOLDERS)}
- set_timer: arg = minutes as a number
- study_status: arg = ""
- say: arg = a short friendly reply in the same language the user used (Urdu or English)

If the request is anything else, use "say" and ask a short question. Never invent other actions."""


# Tried in order. A provider is skipped when its key is missing.
PROVIDERS = [
    {"base_url": os.environ.get("FREELLM_BASE_URL", ""), "key_env": "FREELLM_API_KEY",
     "model": os.environ.get("FREELLM_MODEL", "auto")},
    {"base_url": "https://openrouter.ai/api/v1", "key_env": "OPENROUTER_API_KEY",
     "model": os.environ.get("OPENROUTER_MODEL", "")},
    {"base_url": "https://api.groq.com/openai/v1", "key_env": "GROQ_API_KEY",
     "model": os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")},
    {"base_url": "http://localhost:11434/v1", "key_env": None,
     "model": os.environ.get("OLLAMA_MODEL", "llama3.2")},   # offline last resort
]


def ask_llm(system: str, user: str) -> str:
    last_error = None
    for p in PROVIDERS:
        if not p["model"]:
            continue
        key = os.environ.get(p["key_env"], "") if p["key_env"] else "ollama"
        if p["key_env"] and not key:
            continue
        try:
            client = OpenAI(base_url=p["base_url"], api_key=key, timeout=20)
            resp = client.chat.completions.create(
                model=p["model"], max_tokens=200,
                messages=[{"role": "system", "content": system},
                          {"role": "user", "content": user}],
            )
            return resp.choices[0].message.content.strip()
        except Exception as e:   # rate limit, outage, bad model ID: try next
            print(f"[{p['base_url']}] failed: {e}")
            last_error = e
    raise RuntimeError(f"All providers failed: {last_error}")


def plan(command: str) -> dict:
    text = ask_llm(PLANNER_PROMPT, command)
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return {"action": "say", "arg": "Samajh nahi aaya. Dobara bolein."}
    if data.get("action") not in ACTIONS:
        return {"action": "say", "arg": "Ye kaam abhi allowed nahi hai."}
    return data


def handle(command: str) -> str:
    """Single entry point for voice and phone commands."""
    try:
        data = plan(command)
    except RuntimeError:
        return "Abhi koi AI service available nahi hai. Thori dair baad try karein."
    return ACTIONS[data["action"]](str(data.get("arg", "")))


# ---- Voice input ----
recognizer = sr.Recognizer()


def listen_once() -> str:
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, phrase_time_limit=8)
    try:
        return recognizer.recognize_google(audio, language=LANG)
    except sr.UnknownValueError:
        return ""
    except sr.RequestError:
        speak("Internet nahi mil raha. Speech service band hai.")
        return ""


def voice_loop() -> None:
    speak("Jarvis online.")
    while True:
        heard = listen_once()
        if heard:
            print("HEARD:", heard)
        if not heard or WAKE_WORD not in heard.lower():
            continue
        command = heard.lower().split(WAKE_WORD, 1)[1].strip(" ,.")
        if not command:
            speak("Ji, Saif?")
            command = listen_once()
        if command:
            speak(handle(command))


# ---- Phone commands through the relay (outbound connection, no port forwarding) ----
async def relay_loop() -> None:
    if not RELAY_URL:
        print("RELAY_URL not set. Phone control is off; voice still works.")
        await asyncio.Event().wait()   # keep running so the voice thread stays alive
    while True:
        try:
            async with websockets.connect(RELAY_URL, extra_headers={"Authorization": f"Bearer {RELAY_TOKEN}"}) as ws:
                print("Connected to relay.")
                async for raw in ws:
                    msg = json.loads(raw)
                    reply = handle(msg.get("text", ""))
                    await ws.send(json.dumps({"reply": reply}))
        except Exception as e:  # reconnect after network drops
            print("Relay error, retrying in 10s:", e)
            await asyncio.sleep(10)


def typed_loop() -> None:
    """Type commands in the black window. Works even when the microphone doesn't."""
    print("TYPE MODE: type a command and press Enter (example: timer ek minute ka). Type exit to quit.")
    while True:
        try:
            cmd = input("You: ").strip()
        except EOFError:
            return
        if not cmd:
            continue
        if cmd.lower() in ("exit", "quit"):
            os._exit(0)
        reply = handle(cmd)
        print("JARVIS:", reply)
        try:
            engine.say(reply)
            engine.runAndWait()
        except RuntimeError:
            pass   # speech engine busy in another thread; text reply is still shown


if __name__ == "__main__":
    threading.Thread(target=voice_loop, daemon=True).start()
    threading.Thread(target=typed_loop, daemon=True).start()
    asyncio.run(relay_loop())
