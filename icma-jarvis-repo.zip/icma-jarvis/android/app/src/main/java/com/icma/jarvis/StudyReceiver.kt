package com.icma.jarvis

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

class StudyReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getIntExtra("id", 0)
        val subject = intent.getStringExtra("subject") ?: "Study"
        val topic = intent.getStringExtra("topic") ?: ""

        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("study", "Study alarms", NotificationManager.IMPORTANCE_HIGH)
        )

        val alarmIntent = Intent(ctx, StudyAlarmActivity::class.java)
            .putExtra("subject", subject)
            .putExtra("topic", topic)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val fullScreen = PendingIntent.getActivity(
            ctx, id, alarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Full-screen notification is what makes the alarm appear over a locked phone
        val notification = NotificationCompat.Builder(ctx, "study")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Saif, chalo. Study time.")
            .setContentText("$subject: $topic")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreen, true)
            .setAutoCancel(true)
            .build()
        nm.notify(id, notification)

        // Android may block direct launches from the background; the notification covers that case
        try {
            ctx.startActivity(alarmIntent)
        } catch (e: Exception) {
            // ignored: full-screen notification is shown instead
        }

        // Schedule tomorrow's occurrence of this session
        if (id in StudyScheduler.SESSIONS.indices) {
            StudyScheduler.schedule(ctx, id, StudyScheduler.SESSIONS[id])
        }
    }
}
