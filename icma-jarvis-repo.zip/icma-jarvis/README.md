# ICMA Jarvis

A personal study assistant for ICMAP ML-1 (FACR, BT, OM). It runs a dashboard, a voice and typed command agent on your PC, and daily study alarms on your phone.

## Parts

| Folder | What it does |
|---|---|
| `index.html` (dashboard) | Command-center view of your subjects, chapters, and timetable. Open in a browser. |
| `pc-agent/` | Python agent for your laptop. Takes typed or spoken commands and runs approved actions. |
| `android/` | Android app. Opens the dashboard full screen and sends study alarms with a spoken reminder. |
| `relay/` | Optional server for phone-to-PC control later. Not needed to start. |

## PC agent setup (Windows)

1. Copy the `pc-agent` folder to `Documents\icma-jarvis\pc-agent`.
2. Double-click `setup.bat`. Wait until it says "Setup finished."
3. Rename `.env.example` to `.env` (with the dot) and fill in your free keys:
   - `FREELLM_BASE_URL` and `FREELLM_API_KEY` from FreeLLMAPI's **Unified API key** tab.
   - Optional: `OPENROUTER_API_KEY`, `GROQ_API_KEY`, or Ollama as backups.
4. Edit the `ALLOWED_FOLDERS` path in `agent.py` if your Study folder is elsewhere.
5. Double-click `run_jarvis.bat`. The dashboard opens full screen and Jarvis starts.

### Using Jarvis

- **Typing mode:** type a command at the `You:` prompt, for example `timer ek minute ka`, `YouTube pe study tips lagao`, or `Notepad kholo`. Type `exit` to quit.
- **Voice mode:** say "Jarvis" followed by the command. This needs a working microphone (see Troubleshooting).

### Microphone test

Run from the pc-agent folder, with `.venv` active:
```
python test_mic.py 1
python test_all_mics.py
```

## Android app setup

1. Install Android Studio (free).
2. Create a new project: **Empty Views Activity**, Kotlin, package `com.icma.jarvis`, minimum SDK 26.
3. Replace the generated files with the ones in `android/`, keeping the same folder structure.
4. Build an APK (**Build → Build APK(s)**) and install it on each phone.
5. On first launch, allow notifications and exact alarms.

Edit the `SESSIONS` list in `StudyScheduler.kt` to match your timetable.

## Exam plan

Exam date: **December 5, 2026**. Sessions run after office hours (17:30 onward). Adjust the times in `SESSIONS` and in the dashboard's timeline as your schedule changes.

## Troubleshooting

- **Black window closes immediately:** run `run_jarvis.bat` from a terminal (click the folder's address bar, type `cmd`, press Enter) so you can read the error.
- **"Samajh nahi aaya":** the AI model replied in an unexpected format. Try a different model in `.env`.
- **Failed to reach a provider:** check that FreeLLMAPI is running and that its Outbound proxy toggle is off.
- **No voice input:** check Windows **Sound → Recording**, make sure the microphone isn't muted, and reduce the Microphone Boost. Use typing mode until voice works.
- **Alarms don't ring:** keep the phone on, turn off battery optimization for ICMA Jarvis, and allow exact alarms.

## Security

- Never commit or share `.env`. It holds your API keys.
- Regenerate any key that appears in a photo or chat.
- Jarvis can only run the actions listed in `agent.py`. It has no shell access.
