// Run: RELAY_TOKEN=your_long_secret node relay.js
// Deploy on any host with HTTPS/WSS (Render, Railway, Fly.io, or a VPS).
// PC agent connects to wss://<host>/agent
// Phone app connects to wss://<host>/phone
import { WebSocketServer } from "ws";
import http from "http";

const TOKEN = process.env.RELAY_TOKEN;
if (!TOKEN) throw new Error("Set RELAY_TOKEN");
const PORT = process.env.PORT || 8080;

const server = http.createServer((_, res) => { res.writeHead(200); res.end("relay ok"); });
const wss = new WebSocketServer({ noServer: true });
let agent = null;
const phones = new Set();

server.on("upgrade", (req, socket, head) => {
  const auth = req.headers["authorization"] || "";
  if (auth !== `Bearer ${TOKEN}`) {
    socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");
    return socket.destroy();
  }
  const path = new URL(req.url, "http://x").pathname;
  wss.handleUpgrade(req, socket, head, ws => {
    if (path === "/agent") {
      agent = ws;
      ws.on("close", () => { if (agent === ws) agent = null; });
    } else if (path === "/phone") {
      phones.add(ws);
      ws.on("close", () => phones.delete(ws));
      ws.on("message", raw => {
        if (!agent) return ws.send(JSON.stringify({ reply: "PC offline. Laptop on karein." }));
        agent.send(raw.toString());
        // First reply from the agent goes back to this phone
        agent.once("message", reply => ws.send(reply.toString()));
      });
    } else {
      ws.close();
    }
  });
});

server.listen(PORT, () => console.log("Relay listening on", PORT));
