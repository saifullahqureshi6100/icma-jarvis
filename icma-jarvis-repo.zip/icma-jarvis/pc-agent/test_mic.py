"""
Microphone test for ICMA Jarvis.
Run from the pc-agent folder:  python test_mic.py
It lists microphones, records a few seconds, and prints what it understood.
"""
import speech_recognition as sr

print("Microphones found:")
names = sr.Microphone.list_microphone_names()
if not names:
    print("  NONE. Windows has no microphone available to Python.")
for i, name in enumerate(names):
    print(f"  {i}: {name}")

r = sr.Recognizer()
print("\nAdjusting to room noise, please stay quiet for 1 second...")
try:
    import sys
    device = int(sys.argv[1]) if len(sys.argv) > 1 else None
    print(f"Using microphone number: {device if device is not None else 'default'}")
    with sr.Microphone(device_index=device) as source:
        r.dynamic_energy_threshold = False
        r.energy_threshold = 150   # fixed sensitivity; lower it if speech is still missed
        print("Speak now: say 'Jarvis, timer ek minute ka' (you have 5 seconds)...")
        try:
            audio = r.listen(source, timeout=5, phrase_time_limit=5)
        except sr.WaitTimeoutError:
            print("No sound detected. The microphone is silent or muted.")
            raise SystemExit(1)
except OSError as e:
    print("Could not open the microphone:", e)
    raise SystemExit(1)

print("Sound captured. Sending to Google speech service...")
try:
    print("YOU SAID:", r.recognize_google(audio, language="en-US"))
except sr.UnknownValueError:
    print("Sound captured, but no words were understood. Speak louder and closer to the mic.")
except sr.RequestError as e:
    print("Speech service unreachable. Check internet:", e)
