package com.icma.jarvis

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

data class Session(val hour: Int, val minute: Int, val subject: String, val topic: String)

object StudyScheduler {
    // Edit these to match your timetable (24-hour time, after office hours)
    val SESSIONS = listOf(
        Session(18, 0, "FACR", "IAS 40 investment property"),
        Session(19, 15, "FACR", "Practice set: 10 MCQs"),
        Session(20, 30, "BT", "Property income worked example")
    )

    fun scheduleAll(ctx: Context) {
        SESSIONS.forEachIndexed { id, session -> schedule(ctx, id, session) }
    }

    fun schedule(ctx: Context, id: Int, s: Session) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, s.hour)
            set(Calendar.MINUTE, s.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            // If that time already passed today, schedule for tomorrow
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = Intent(ctx, StudyReceiver::class.java)
            .putExtra("id", id)
            .putExtra("subject", s.subject)
            .putExtra("topic", s.topic)
        val pi = PendingIntent.getBroadcast(
            ctx, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
    }
}
