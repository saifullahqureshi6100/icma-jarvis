@echo off
cd /d "%~dp0"
call .venv\Scripts\activate

set "DASH=https://claude.ai/artifact/LqsdgakK2sPf9hkAYh6shh"
for /f "usebackq tokens=1,* delims==" %%a in (".env") do (
  if /i "%%a"=="DASHBOARD_URL" set "DASH=%%b"
)

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "EDGE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"

if exist "%CHROME%" (
  start "" "%CHROME%" --app=%DASH% --start-fullscreen
) else if exist "%EDGE%" (
  start "" "%EDGE%" --app=%DASH% --start-fullscreen
) else (
  start "" "%DASH%"
  echo Chrome/Edge not found. Press F11 in your browser for fullscreen.
)

python agent.py
pause
