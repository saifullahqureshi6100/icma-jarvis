@echo off
cd /d "%~dp0"
echo === ICMA Jarvis setup ===

python --version >nul 2>&1
if errorlevel 1 (
  echo Python not found. Install Python 3.10+ from python.org and tick "Add to PATH", then run this again.
  pause
  exit /b 1
)

python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo PyAudio failed. Trying pipwin...
  pip install pipwin
  pipwin install pyaudio
)

if not exist .env (
  copy .env.example .env >nul
  echo Created .env. Open it, add your free keys, then run run_jarvis.bat
) else (
  echo .env already exists. Keeping your keys.
)

echo.
echo Setup finished.
pause
