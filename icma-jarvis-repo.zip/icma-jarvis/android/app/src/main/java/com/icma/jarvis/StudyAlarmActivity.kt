package com.icma.jarvis

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class StudyAlarmActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var message = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val subject = intent.getStringExtra("subject") ?: "Study"
        val topic = intent.getStringExtra("topic") ?: ""
        message = "Saif, chalo. It's study time. $subject. $topic."

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(3, 12, 24))
            setPadding(60, 200, 60, 60)
        }
        layout.addView(TextView(this).apply {
            text = "JARVIS"
            textSize = 34f
            setTextColor(Color.rgb(79, 211, 255))
        })
        layout.addView(TextView(this).apply {
            text = "Saif, chalo. Study time."
            textSize = 24f
            setTextColor(Color.WHITE)
        })
        layout.addView(TextView(this).apply {
            text = "$subject: $topic"
            textSize = 18f
            setTextColor(Color.rgb(159, 233, 255))
        })
        layout.addView(Button(this).apply {
            text = "START"
            setOnClickListener { finish() }
        })
        setContentView(layout)

        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "study")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
