"""
Tests every microphone device one by one.
Run:  python test_all_mics.py
For each device, speak "Jarvis, timer ek minute ka" when it says LISTEN.
"""
import speech_recognition as sr

names = sr.Microphone.list_microphone_names()
r = sr.Recognizer()
found_any = False

for idx, name in enumerate(names):
    if "Sound Mapper" in name or "Primary Sound" in name:
        continue  # virtual devices, skip
    print(f"\n[{idx}] {name}")
    try:
        with sr.Microphone(device_index=idx) as source:
            r.adjust_for_ambient_noise(source, duration=0.5)
            print("  LISTEN now (5 seconds)...")
            audio = r.listen(source, timeout=5, phrase_time_limit=4)
    except sr.WaitTimeoutError:
        print("  silence")
        continue
    except OSError as e:
        print("  cannot open:", e)
        continue

    print("  sound captured, checking words...")
    try:
        text = r.recognize_google(audio, language="en-US")
        print("  YOU SAID:", text)
        found_any = True
    except sr.UnknownValueError:
        print("  sound captured, but no words understood")
    except sr.RequestError as e:
        print("  speech service unreachable:", e)

print("\nDone.", "Working microphone found above." if found_any else "No words understood on any device.")
